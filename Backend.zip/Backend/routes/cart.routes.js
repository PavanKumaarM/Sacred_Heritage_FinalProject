const router = require("express").Router();

const controller = require("../controllers/cart.controller");
const asyncHandler = require("../middleware/asyncHandler");
const { protect } = require("../middleware/auth.middleware");

router.use(protect);

router.get("/", asyncHandler(controller.getCart));

router.post("/items", asyncHandler(controller.addItem));

router.patch("/items/:itemId", asyncHandler(controller.updateItem));

router.delete("/items/:itemId", asyncHandler(controller.removeItem));

router.delete("/", asyncHandler(controller.clearCart));

module.exports = router;